# Github stats finder

Internet Engineering Midterm Project




## Description
This is a simple web page that allows you to find the stats of a github user.

## How to use

1. Go to [https://mohamadch91.github.io/IE-Midterm](https://mohamadch91.github.io/IE-Midterm)

2. Enter the username of the github user you want to find the stats of.

3. Click on the Search button.
   
4. The stats will be displayed.

## How to run locally

1. Clone the repository


2. Open the index.html file in your browser.


   